MUHRAM PRIVÉ — READY TO PUBLISH
=================================
WhatsApp: +218 93 026 8353
Order method: Cash on Delivery (COD)
Suggested domain: MUHRAMPRIVE.COM

FASTEST PUBLISH METHOD
1. Create a GitHub account you control.
2. Create a new repository named: muhram-prive
3. Upload ALL files in this folder to the repository root.
4. Go to Settings → Pages.
5. Under Build and deployment, choose GitHub Actions.
6. Wait for the workflow to finish.
7. Your site will be live at the GitHub Pages URL shown there.
8. Later, connect MUHRAMPRIVE.COM from Settings → Pages → Custom domain.

IMPORTANT
This package is a static storefront. It supports product browsing, cart and WhatsApp/COD ordering.
The current admin.html is a local editor, not a secure cloud admin/database.
For a fully cloud-managed store with secure login, live inventory and order dashboard, a backend/database must be added.
